# ELAM reproducibility code (research implementation scaffold)

This repository contains a non-placeholder, model-agnostic implementation of the core ELAM operations described in the manuscript: layer-gradient calibration, top-K layer selection, activation-gradient attribution, weighted aggregation, optional attention-map fusion, insertion/deletion, pointing-game scoring, and baseline attribution utilities.

## Important scope and reproducibility note

The supplied `code.txt` notebook was not a complete implementation: it returned random insertion/deletion values, registered no hooks, returned no attention map, disabled LLaVA, evaluated only one example, and did not implement the stated Flickr30k/pointing-game/baseline protocol. This repository replaces those placeholders with working generic routines. **It is not yet a verified reproduction of the manuscript's reported Tables 2–5 or Figures 2–4.** The paper-specific model adapters, exact target-score definitions, attention extraction for each architecture, dataset manifests/ground-truth boxes, and actual experiment outputs must be supplied and run on the authors' original checkpoints and hardware before claiming full reproduction.

In particular, CLIP is a dual encoder and does not expose text-to-image cross-attention in the same way as BLIP-2's Q-Former or LLaVA's multimodal transformer. Do not describe a CLIP self-attention map as cross-modal attention. The adapter must document which attention tensor is used for each model.

## Install

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
pip install -e .
```

## Required model adapter contract

The ELAM core intentionally requires the model-specific parts to be explicit:

1. `layers`: ordered vision or multimodal transformer modules to instrument.
2. `score_fn(image_tensor, text)`: returns one differentiable scalar score for the selected image-text decision. Use the same score definition for ELAM, IG, Gradient × Input, insertion and deletion.
3. `attention_map`: optional, nonnegative spatial map extracted from the selected model's actual attention tensors. Pass `None` only if attention is not available; the result is then gradient-only and must not be reported as hybrid ELAM.

Example skeleton: see `examples/adapter_template.py`. Do not substitute a constant score or random value.

## Core API

```python
from elam import ELAM, integrated_gradients, gradient_x_input

explainer = ELAM(layers=vision_layers, score_fn=score_fn,
                 num_layers=5, fusion_weight=0.73, temperature=1.0)
explainer.calibrate(calibration_images, calibration_texts)  # disjoint training/calibration set
heatmap, score = explainer.explain(image_tensor, caption, attention_map=attention_map)
```

Images must be normalized exactly as required by the selected model's processor. `image_tensor` is expected to have shape `1 x 3 x H x W` (or a batch compatible with the score function). For transformer token layers, set `patch_grid=(height_patches, width_patches)` and ensure CLS-token handling is consistent with the selected layer.

## Evaluation

`elam.metrics.insertion_deletion` computes insertion and deletion AUC using a fixed baseline and the same scalar `score_fn`; `insdel = insertion_auc - deletion_auc`. `pointing_game` evaluates the maximum-saliency location against supplied bounding boxes. The CSV loader expects `image_path,text` and optional `x1,y1,x2,y2` columns. Supply the actual COCO/Flickr30k evaluation manifests; the repository does not fabricate or download evaluation annotations.

The five manuscript baselines are exposed as utilities where architecture requirements permit: Integrated Gradients (50 steps by default when called with `steps=50`), Gradient × Input, GradCAM (requires a suitable target layer), Attention Rollout (requires captured attention tensors), and Transformer Attribution (requires attention and corresponding gradients). These methods do not automatically infer architecture-specific attention tensors.

## Before publishing experimental claims

- Implement and test separate adapters for CLIP-ViT-L/14, BLIP-2, and LLaVA-1.5-7B using the exact checkpoint revisions and target scalar described in the paper.
- Verify forward/backward hooks fire and gradients are finite/non-zero for every selected layer.
- Verify attention tensors are genuinely extracted for the relevant architecture; record layer/head/token dimensions.
- Run the complete 1,500 MS-COCO + 1,000 Flickr30k evaluation, with the 50-sample calibration set disjoint from evaluation.
- Record per-sample outputs, seeds, precision, GPU count, offloading configuration, peak allocated memory, and timing protocol.
- Regenerate every table and figure from saved raw outputs. Never enter published values manually.

## Repository structure

- `elam/core.py`: calibration, hooks, selected-layer gradient attribution, fusion.
- `elam/baselines.py`: IG, Gradient × Input, GradCAM, attention rollout, transformer attribution.
- `elam/metrics.py`: insertion/deletion, pointing game, timing, peak CUDA memory.
- `elam/data.py`: CSV-manifest image/caption/box loader.
- `examples/adapter_template.py`: explicit model-adapter template.
- `tests/`: unit tests for metrics and attribution utilities.
