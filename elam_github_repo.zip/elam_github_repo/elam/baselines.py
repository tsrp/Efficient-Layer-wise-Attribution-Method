"""Attribution baselines operating on a differentiable score_fn(image, text)."""
import torch
import torch.nn.functional as F

def _normalize(x):
    x = x - x.amin(dim=(-2, -1), keepdim=True)
    return x / x.amax(dim=(-2, -1), keepdim=True).clamp_min(1e-8)

def gradient_x_input(score_fn, image, text):
    x = image.detach().clone().requires_grad_(True)
    score = score_fn(x, text).reshape(-1)[0]
    grad, = torch.autograd.grad(score, x)
    return _normalize((x * grad).abs().sum(dim=1, keepdim=True)).detach()

def integrated_gradients(score_fn, image, text, steps=50, baseline=None):
    if steps < 1: raise ValueError("steps must be positive")
    if baseline is None: baseline = torch.zeros_like(image)
    delta = image - baseline
    total = torch.zeros_like(image)
    # Trapezoidal integration includes both endpoints.
    for alpha in torch.linspace(0, 1, steps + 1, device=image.device):
        x = (baseline + alpha * delta).detach().requires_grad_(True)
        score = score_fn(x, text).reshape(-1)[0]
        grad, = torch.autograd.grad(score, x)
        weight = 0.5 if alpha.item() in (0.0, 1.0) else 1.0
        total += weight * grad
    attr = delta * total / steps
    return _normalize(attr.abs().sum(dim=1, keepdim=True)).detach()

def gradcam(score_fn, image, text, target_layer):
    state = {}
    def fwd(_m, _i, out):
        tensor = out[0] if isinstance(out, (tuple, list)) else out
        state['a'] = tensor
        if tensor.requires_grad:
            tensor.register_hook(lambda g: state.__setitem__('g', g))
    handle = target_layer.register_forward_hook(fwd)
    try:
        score = score_fn(image, text).reshape(-1)[0]
        score.backward()
        a, g = state['a'], state.get('g')
        if g is None: raise RuntimeError("GradCAM target layer did not receive gradients")
        if a.ndim == 3:
            # ViT token features: channel-average gradient-weighted activation.
            cam = torch.relu((a * g).sum(-1))[:, None, :]
            n = cam.shape[-1]; side = int(n ** 0.5)
            if side * side != n: raise ValueError("GradCAM token count must be square; remove CLS or supply a model-specific reshape")
            cam = cam.reshape(a.shape[0], 1, side, side)
        elif a.ndim == 4:
            weights = g.mean(dim=(-2, -1), keepdim=True)
            cam = torch.relu((weights * a).sum(dim=1, keepdim=True))
        else: raise ValueError("GradCAM expects 3D token or 4D feature activations")
        cam = F.interpolate(cam, size=image.shape[-2:], mode='bilinear', align_corners=False)
        return _normalize(cam).detach()
    finally:
        handle.remove()

def attention_rollout(attentions):
    """attentions: iterable of BxHeadsxTokensxTokens attention tensors."""
    mats = []
    for a in attentions:
        a = a.mean(dim=1)
        eye = torch.eye(a.shape[-1], device=a.device, dtype=a.dtype)[None]
        a = a + eye
        a = a / a.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        mats.append(a)
    if not mats: raise ValueError("No attention tensors supplied")
    joint = mats[0]
    for a in mats[1:]: joint = a @ joint
    return joint

def transformer_attribution(attentions, gradients):
    """Gradient-weighted attention rollout; both lists must align by layer."""
    if len(attentions) != len(gradients) or not attentions:
        raise ValueError("attention and gradient lists must be non-empty and aligned")
    weighted = []
    for a, g in zip(attentions, gradients):
        # average heads; retain positive gradient-supported attention
        weighted.append(torch.relu((a * g).mean(dim=1)))
    return attention_rollout(weighted)
