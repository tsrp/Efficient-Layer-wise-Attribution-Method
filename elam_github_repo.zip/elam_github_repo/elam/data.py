"""CSV-manifest dataset loader. Expected columns: image_path,text[,x1,y1,x2,y2]."""
import csv
from pathlib import Path
from PIL import Image

def load_manifest(csv_path, image_root=None):
    csv_path = Path(csv_path); root = Path(image_root) if image_root else csv_path.parent
    rows = []
    with csv_path.open(newline='', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            path = Path(row['image_path'])
            if not path.is_absolute(): path = root / path
            if not path.is_file(): raise FileNotFoundError(path)
            with Image.open(path) as im: image = im.convert('RGB').copy()
            boxes = []
            if all(k in row and row[k] not in ('', None) for k in ('x1','y1','x2','y2')):
                boxes.append(tuple(float(row[k]) for k in ('x1','y1','x2','y2')))
            rows.append({'image': image, 'text': row['text'], 'image_path': str(path), 'boxes': boxes})
    return rows
