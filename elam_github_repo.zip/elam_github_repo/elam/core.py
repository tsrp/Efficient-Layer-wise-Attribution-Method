"""Model-agnostic ELAM core.

The caller supplies a differentiable score_fn(image_tensor, text) -> scalar tensor
and a list of vision-layer modules. This keeps model-specific preprocessing and
scoring explicit instead of silently assuming incompatible Hugging Face outputs.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Sequence
import torch
import torch.nn.functional as F

ScoreFn = Callable[[torch.Tensor, str], torch.Tensor]

@dataclass
class LayerRecord:
    activation: torch.Tensor
    gradient: torch.Tensor | None = None

class ELAM:
    def __init__(self, layers: Sequence[torch.nn.Module], score_fn: ScoreFn,
                 num_layers: int = 5, fusion_weight: float = 0.73,
                 temperature: float = 1.0, patch_grid: tuple[int, int] | None = None):
        if not layers:
            raise ValueError("At least one target layer is required")
        if not 1 <= num_layers <= len(layers):
            raise ValueError("num_layers must be between 1 and len(layers)")
        if not 0.0 <= fusion_weight <= 1.0:
            raise ValueError("fusion_weight must be in [0, 1]")
        if temperature <= 0:
            raise ValueError("temperature must be positive")
        self.layers, self.score_fn = list(layers), score_fn
        self.num_layers, self.fusion_weight = num_layers, fusion_weight
        self.temperature, self.patch_grid = temperature, patch_grid
        self.selected, self.weights = [], None

    def _capture(self, selected_indices):
        records: dict[int, LayerRecord] = {}
        handles = []
        for idx in selected_indices:
            def hook(_module, _inputs, output, layer_idx=idx):
                tensor = output[0] if isinstance(output, (tuple, list)) else output
                if not torch.is_tensor(tensor):
                    raise TypeError(f"Layer {layer_idx} did not return a tensor")
                rec = LayerRecord(tensor)
                records[layer_idx] = rec
                if tensor.requires_grad:
                    tensor.register_hook(lambda grad, r=rec: setattr(r, 'gradient', grad))
            handles.append(self.layers[idx].register_forward_hook(hook))
        return records, handles

    @staticmethod
    def _spatial_map(value: torch.Tensor, grid=None) -> torch.Tensor:
        """Convert BxTokensxChannels or BxChannelsxHxW to Bx1xHxW."""
        if value.ndim == 4:
            return value.abs().mean(dim=1, keepdim=True)
        if value.ndim != 3:
            raise ValueError(f"Expected 3D token or 4D feature tensor, got {tuple(value.shape)}")
        # Treat token dimension as sequence; remove CLS only when grid proves it exists.
        tokens = value.shape[1]
        if grid is None:
            side = int(tokens ** 0.5)
            if side * side != tokens:
                raise ValueError("Non-square token sequence: provide patch_grid and ensure CLS handling is explicit")
            h, w = side, side
        else:
            h, w = grid
            if tokens == h * w + 1:  # conventional CLS token
                value = value[:, 1:, :]
            elif tokens != h * w:
                raise ValueError(f"Token count {tokens} is incompatible with patch grid {grid}")
        return value.abs().mean(dim=-1).reshape(value.shape[0], 1, h, w)

    @staticmethod
    def _normalize(x):
        x = x - x.amin(dim=(-2, -1), keepdim=True)
        return x / x.amax(dim=(-2, -1), keepdim=True).clamp_min(1e-8)

    def calibrate(self, images: Sequence[torch.Tensor], texts: Sequence[str]):
        if len(images) != len(texts) or not images:
            raise ValueError("images and texts must be non-empty and have equal lengths")
        scores = torch.zeros(len(self.layers), dtype=torch.float64)
        # Calibration score is the L2 norm of d(score)/d(layer activation),
        # consistent with the layer-wise gradient-importance principle.
        for image, text in zip(images, texts):
            records, handles = self._capture(range(len(self.layers)))
            try:
                self._zero_model_grads()
                score = self.score_fn(image, text)
                if score.numel() != 1:
                    score = score.reshape(-1)[0]
                score.backward()
                for i, rec in records.items():
                    if rec.gradient is not None:
                        scores[i] += rec.gradient.detach().float().norm().cpu().double()
            finally:
                for handle in handles: handle.remove()
        scores /= len(images)
        if not torch.isfinite(scores).all() or scores.max() <= 0:
            raise RuntimeError("Calibration produced no finite, non-zero layer gradients")
        self.selected = torch.topk(scores, self.num_layers).indices.sort().values.tolist()
        chosen = scores[self.selected]
        self.weights = torch.softmax(chosen / self.temperature, dim=0).float()
        return {"selected_layers": self.selected, "layer_scores": scores.tolist(),
                "layer_weights": self.weights.tolist()}

    def _zero_model_grads(self):
        # score_fn may close over a model; clear gradients on the layers' root modules
        for layer in self.layers:
            for p in layer.parameters(recurse=True):
                if p.grad is not None: p.grad = None

    def explain(self, image: torch.Tensor, text: str, attention_map: torch.Tensor | None = None):
        if self.weights is None:
            raise RuntimeError("Call calibrate() before explain()")
        records, handles = self._capture(self.selected)
        try:
            self._zero_model_grads()
            score = self.score_fn(image, text)
            if score.numel() != 1: score = score.reshape(-1)[0]
            score.backward()
            maps = []
            out_h, out_w = image.shape[-2:]
            for i, layer_idx in enumerate(self.selected):
                rec = records.get(layer_idx)
                if rec is None or rec.gradient is None:
                    raise RuntimeError(f"No activation gradient captured for selected layer {layer_idx}")
                # Positive activation-gradient evidence; token channels are averaged.
                product = F.relu(rec.activation * rec.gradient)
                spatial = self._spatial_map(product, self.patch_grid)
                spatial = F.interpolate(spatial, size=(out_h, out_w), mode="bilinear", align_corners=False)
                maps.append(self.weights[i].to(spatial.device) * spatial)
            grad_map = torch.stack(maps).sum(0)
            if attention_map is None:
                fused = grad_map
            else:
                if attention_map.ndim == 2: attention_map = attention_map[None, None]
                elif attention_map.ndim == 3: attention_map = attention_map[:, None]
                attention_map = F.interpolate(attention_map.float(), size=(out_h, out_w), mode="bilinear", align_corners=False)
                fused = self.fusion_weight * grad_map + (1 - self.fusion_weight) * attention_map
            return self._normalize(fused).detach(), float(score.detach().cpu())
        finally:
            for handle in handles: handle.remove()
