"""Faithfulness and runtime metrics for image attribution maps."""
import time
import numpy as np
import torch
import torch.nn.functional as F

@torch.no_grad()
def insertion_deletion(score_fn, image, text, attribution, steps=100, baseline=None):
    if steps < 2: raise ValueError("steps must be >= 2")
    if attribution.ndim == 4: attribution = attribution[0, 0]
    elif attribution.ndim == 3: attribution = attribution[0]
    if baseline is None: baseline = torch.zeros_like(image)
    flat_order = torch.argsort(attribution.reshape(-1), descending=True)
    n = flat_order.numel(); curve_ins, curve_del = [], []
    original = image.detach().clone()
    for k in range(steps + 1):
        count = int(round(k * n / steps))
        mask = torch.zeros(n, device=image.device, dtype=image.dtype)
        if count: mask[flat_order[:count]] = 1
        mask = mask.reshape(1, 1, *attribution.shape[-2:])
        mask = F.interpolate(mask, size=image.shape[-2:], mode="nearest")
        ins = baseline * (1-mask) + original * mask
        dele = original * (1-mask) + baseline * mask
        curve_ins.append(float(score_fn(ins, text).reshape(-1)[0].item()))
        curve_del.append(float(score_fn(dele, text).reshape(-1)[0].item()))
    x = np.linspace(0, 1, steps + 1)
    auc_ins, auc_del = float(np.trapezoid(curve_ins, x)), float(np.trapezoid(curve_del, x))
    return {"insertion_auc": auc_ins, "deletion_auc": auc_del,
            "insdel": auc_ins - auc_del,
            "insertion_curve": curve_ins, "deletion_curve": curve_del}

def pointing_game(attribution, boxes):
    """Return hit and valid count. boxes are xyxy in attribution-map coordinates."""
    if attribution.ndim == 4: attribution = attribution[0, 0]
    elif attribution.ndim == 3: attribution = attribution[0]
    if not boxes: return {"hits": 0, "count": 0, "accuracy": float("nan")}
    y, x = torch.unravel_index(torch.argmax(attribution), attribution.shape)
    x, y = int(x), int(y)
    hit = any(x1 <= x <= x2 and y1 <= y <= y2 for x1, y1, x2, y2 in boxes)
    return {"hits": int(hit), "count": 1, "accuracy": float(hit)}

def timed_call(fn, repeats=3, device=None):
    values = []
    for _ in range(repeats):
        if device is not None and str(device).startswith("cuda"): torch.cuda.synchronize(device)
        start = time.perf_counter(); fn()
        if device is not None and str(device).startswith("cuda"): torch.cuda.synchronize(device)
        values.append(time.perf_counter() - start)
    return {"mean_seconds": float(np.mean(values)), "std_seconds": float(np.std(values))}

def peak_cuda_memory(fn, device=0):
    if not torch.cuda.is_available():
        fn(); return None
    torch.cuda.reset_peak_memory_stats(device)
    fn(); torch.cuda.synchronize(device)
    return float(torch.cuda.max_memory_allocated(device) / (1024**3))
