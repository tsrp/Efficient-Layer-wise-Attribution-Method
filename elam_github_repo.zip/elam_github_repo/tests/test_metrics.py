import torch
from elam.metrics import insertion_deletion, pointing_game

def test_pointing_game_hit():
    a = torch.zeros(1, 1, 8, 8); a[0, 0, 3, 4] = 1
    assert pointing_game(a, [(2, 2, 5, 5)])['accuracy'] == 1.0

def test_insertion_deletion_returns_finite_values():
    image = torch.ones(1, 3, 8, 8)
    attr = torch.zeros(1, 1, 8, 8); attr[:, :, :4, :4] = 1
    def score_fn(x, _text): return x.mean()
    result = insertion_deletion(score_fn, image, 'object', attr, steps=4)
    assert torch.isfinite(torch.tensor(result['insdel']))
    assert len(result['insertion_curve']) == 5
