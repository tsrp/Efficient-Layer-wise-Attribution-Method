"""Template only: replace every TODO with the actual model's documented API."""
import torch
from elam import ELAM

# TODO: load the exact pretrained model and processor used in the experiment.
model = None
processor = None
vision_layers = None

def score_fn(image_tensor: torch.Tensor, text: str) -> torch.Tensor:
    """Return one differentiable scalar for the image-text pair.

    IMPORTANT: choose and document the target score (e.g. image-text similarity
    logit or a specified answer-token logit) and use it for every method/metric.
    Do not return a constant, detached tensor, or batch mean unrelated to target.
    """
    raise NotImplementedError("Implement using the selected VLM's forward API")

def extract_attention_map(image_tensor, text, selected_layers):
    """Return Bx1xHxW attention attribution or None if unavailable.

    Capture actual attention probability tensors and document whether they are
    cross-modal, self-attention, or Q-Former attention. Never label self-attention
    as cross-modal attention.
    """
    raise NotImplementedError("Implement architecture-specific attention extraction")

# After implementing the adapter:
# explainer = ELAM(vision_layers, score_fn, num_layers=5, patch_grid=(16, 16))
# calibration = [...]  # 50 held-out calibration image tensors
# captions = [...]
# explainer.calibrate(calibration, captions)
# heatmap, target_score = explainer.explain(test_image, test_caption,
#                                           attention_map=extract_attention_map(...))
