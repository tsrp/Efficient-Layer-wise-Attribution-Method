"""Faithfulness and localization metrics for image attribution maps."""
from __future__ import annotations
from typing import Callable, Iterable, Optional, Sequence, Tuple
import numpy as np
import torch
import torch.nn.functional as F
from torch import Tensor


def _score(score_fn: Callable[[Tensor], Tensor], image: Tensor) -> float:
    value = score_fn(image)
    if not torch.is_tensor(value):
        value = torch.tensor(value)
    return float(value.detach().float().mean().cpu())


def insertion_deletion(
    image: Tensor,
    attribution: Tensor,
    score_fn: Callable[[Tensor], Tensor],
    steps: int = 100,
    baseline: Optional[Tensor] = None,
) -> dict:
    """Return insertion AUC, deletion AUC and InsDel = insertion - deletion.

    image: [1,C,H,W] or [C,H,W]; attribution: [1,1,H,W] or [H,W].
    Pixels are inserted/deleted in descending attribution order.
    """
    if image.ndim == 3:
        image = image.unsqueeze(0)
    if attribution.ndim == 4:
        saliency = attribution[0, 0]
    elif attribution.ndim == 3:
        saliency = attribution[0]
    else:
        saliency = attribution
    if saliency.shape != image.shape[-2:]:
        saliency = F.interpolate(
            saliency[None, None].float(), size=image.shape[-2:],
            mode="bilinear", align_corners=False
        )[0, 0]
    flat_order = torch.argsort(saliency.reshape(-1), descending=True)
    total = flat_order.numel()
    steps = max(1, min(int(steps), total))
    baseline = torch.zeros_like(image) if baseline is None else baseline.to(image.device)
    if baseline.ndim == 3:
        baseline = baseline.unsqueeze(0)
    insertion_curve, deletion_curve = [], []
    insertion = baseline.clone()
    deletion = image.clone()
    insertion_curve.append(_score(score_fn, insertion))
    deletion_curve.append(_score(score_fn, deletion))
    for step in range(1, steps + 1):
        end = round(step * total / steps)
        ids = flat_order[(round((step - 1) * total / steps)):end]
        mask = torch.zeros(total, device=image.device, dtype=torch.bool)
        mask[flat_order[:end]] = True
        mask = mask.reshape(1, 1, *image.shape[-2:])
        insertion = torch.where(mask, image, baseline)
        deletion = torch.where(mask, baseline, image)
        insertion_curve.append(_score(score_fn, insertion))
        deletion_curve.append(_score(score_fn, deletion))
    x = np.linspace(0.0, 1.0, len(insertion_curve))
    ins_auc = float(np.trapz(insertion_curve, x))
    del_auc = float(np.trapz(deletion_curve, x))
    return {
        "insertion_auc": ins_auc,
        "deletion_auc": del_auc,
        "insdel": ins_auc - del_auc,
        "insertion_curve": insertion_curve,
        "deletion_curve": deletion_curve,
    }


def pointing_game(attribution: Tensor, boxes: Sequence[Tuple[float, float, float, float]]) -> Optional[int]:
    """Return 1 if the maximum-saliency pixel falls inside any (x1,y1,x2,y2) box.

    Coordinates are in the attribution map's pixel coordinate system.
    Return None when no boxes are supplied.
    """
    if not boxes:
        return None
    if attribution.ndim == 4:
        sal = attribution[0, 0]
    elif attribution.ndim == 3:
        sal = attribution[0]
    else:
        sal = attribution
    y, x = torch.nonzero(sal == sal.max(), as_tuple=True)
    px, py = int(x[0]), int(y[0])
    return int(any(x1 <= px <= x2 and y1 <= py <= y2 for x1, y1, x2, y2 in boxes))


def fidelity_retention(insdel_method: float, insdel_ig: float, eps: float = 1e-12) -> float:
    return 100.0 * insdel_method / max(abs(insdel_ig), eps)


def measure_runtime(fn, repeats: int = 3, warmup: int = 1) -> dict:
    import time
    for _ in range(warmup):
        fn()
    if torch.cuda.is_available():
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
    times = []
    for _ in range(repeats):
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        start = time.perf_counter()
        fn()
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        times.append(time.perf_counter() - start)
    peak_gib = (
        torch.cuda.max_memory_allocated() / (1024 ** 3)
        if torch.cuda.is_available() else None
    )
    return {
        "time_mean_s": float(np.mean(times)),
        "time_std_s": float(np.std(times, ddof=1)) if len(times) > 1 else 0.0,
        "peak_gpu_memory_gib": peak_gib,
    }
