"""Core ELAM implementation.

This module contains the reusable attribution, hook, calibration, and fusion logic.
Model-specific input preparation, scalar target selection, and attention extraction
are supplied through a VLMAdapter implementation.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import math
import torch
import torch.nn.functional as F
from torch import Tensor, nn


@dataclass
class Explanation:
    attribution: Tensor
    gradient_attribution: Tensor
    attention_attribution: Optional[Tensor]
    selected_layers: List[int]
    layer_weights: Tensor


class VLMAdapter:
    """Adapter contract for a vision-language model.

    `score(image, text)` must return one scalar tensor whose increase means
    stronger support for the supplied image-text pair.
    `visual_layers` must return an ordered list of modules whose outputs retain
    spatial/patch tokens (or can be converted to a spatial map).
    `attention_maps` may return attention tensors shaped [B, heads, query, key].
    """
    def score(self, image: Tensor, text: str) -> Tensor:
        raise NotImplementedError

    def visual_layers(self) -> Sequence[nn.Module]:
        raise NotImplementedError

    def attention_maps(self, image: Tensor, text: str) -> Sequence[Tensor]:
        return []


def _tensor_from_output(output) -> Tensor:
    if isinstance(output, Tensor):
        return output
    if isinstance(output, (tuple, list)):
        for item in output:
            if isinstance(item, Tensor):
                return item
    if hasattr(output, "last_hidden_state"):
        return output.last_hidden_state
    raise TypeError(f"Unsupported layer output type: {type(output)!r}")


def _spatialize(tokens: Tensor, height: int, width: int) -> Tensor:
    """Convert [B,N,C] tokens or [B,C,H,W] maps to [B,1,H,W]."""
    if tokens.ndim == 4:
        return tokens.float().abs().mean(dim=1, keepdim=True)
    if tokens.ndim != 3:
        raise ValueError(f"Expected a 3-D token or 4-D feature tensor, got {tuple(tokens.shape)}")
    # Remove a likely CLS token only when the remaining token count is square.
    n = tokens.shape[1]
    side = math.isqrt(n)
    if side * side != n and n > 1 and math.isqrt(n - 1) ** 2 == n - 1:
        tokens = tokens[:, 1:, :]
        n -= 1
        side = math.isqrt(n)
    if side * side != n:
        raise ValueError(
            f"Cannot infer a square patch grid from {n} tokens. "
            "Override the adapter's spatial conversion for this architecture."
        )
    return tokens.float().abs().mean(dim=-1).reshape(tokens.shape[0], 1, side, side)


def normalize_map(x: Tensor, eps: float = 1e-8) -> Tensor:
    x = x.float()
    lo = x.amin(dim=(-2, -1), keepdim=True)
    hi = x.amax(dim=(-2, -1), keepdim=True)
    return (x - lo) / (hi - lo).clamp_min(eps)


class ELAM:
    """Efficient Layer-wise Attribution Method.

    Calibration ranks layers using mean L2 norm of d(score)/d(activation).
    Explanation stores activations and their gradients only at selected layers.
    """
    def __init__(
        self,
        adapter: VLMAdapter,
        num_layers: int = 5,
        fusion_weight: float = 0.73,
        temperature: float = 1.0,
    ):
        if num_layers < 1:
            raise ValueError("num_layers must be >= 1")
        if not 0.0 <= fusion_weight <= 1.0:
            raise ValueError("fusion_weight must be in [0, 1]")
        self.adapter = adapter
        self.num_layers = num_layers
        self.fusion_weight = fusion_weight
        self.temperature = temperature
        self.selected_layers: List[int] = []
        self.layer_weights: Optional[Tensor] = None

    def _capture(self, modules, activations, gradients, selected=None):
        handles = []
        indices = range(len(modules)) if selected is None else selected
        for idx in indices:
            module = modules[idx]

            def hook(_module, _inputs, output, layer_idx=idx):
                value = _tensor_from_output(output)
                activations[layer_idx] = value
                if value.requires_grad:
                    value.register_hook(
                        lambda grad, key=layer_idx: gradients.__setitem__(key, grad.detach())
                    )

            handles.append(module.register_forward_hook(hook))
        return handles

    def calibrate(self, samples: Sequence[Tuple[Tensor, str]]) -> List[int]:
        if not samples:
            raise ValueError("Calibration requires at least one (image_tensor, text) sample.")
        modules = list(self.adapter.visual_layers())
        if not modules:
            raise RuntimeError("The adapter returned no visual layers.")
        scores = torch.zeros(len(modules), dtype=torch.float64)
        count = 0
        for image, text in samples:
            activations, gradients = {}, {}
            handles = self._capture(modules, activations, gradients)
            try:
                self.adapter.model_zero_grad() if hasattr(self.adapter, "model_zero_grad") else None
                target = self.adapter.score(image, text)
                if target.numel() != 1:
                    target = target.reshape(-1).mean()
                target.backward()
                for idx, grad in gradients.items():
                    scores[idx] += grad.detach().float().norm(p=2).cpu().double()
                count += 1
            finally:
                for handle in handles:
                    handle.remove()
        if count == 0 or scores.max().item() <= 0:
            raise RuntimeError("Calibration produced no non-zero activation gradients.")
        scores /= count
        k = min(self.num_layers, len(modules))
        selected = torch.topk(scores, k=k, largest=True).indices.sort().values.tolist()
        selected_scores = scores[selected].float()
        self.layer_weights = torch.softmax(selected_scores / max(self.temperature, 1e-8), dim=0)
        self.selected_layers = [int(i) for i in selected]
        return self.selected_layers

    def explain(self, image: Tensor, text: str, output_size: Optional[Tuple[int, int]] = None) -> Explanation:
        if not self.selected_layers or self.layer_weights is None:
            raise RuntimeError("Call calibrate() before explain().")
        modules = list(self.adapter.visual_layers())
        activations, gradients = {}, {}
        handles = self._capture(modules, activations, gradients, self.selected_layers)
        try:
            if hasattr(self.adapter, "model_zero_grad"):
                self.adapter.model_zero_grad()
            score = self.adapter.score(image, text)
            if score.numel() != 1:
                score = score.reshape(-1).mean()
            score.backward()
        finally:
            for handle in handles:
                handle.remove()

        if not activations or not gradients:
            raise RuntimeError("No activations/gradients were captured; check adapter layer paths.")
        h, w = output_size or (int(image.shape[-2]), int(image.shape[-1]))
        grad_map = None
        for pos, layer_idx in enumerate(self.selected_layers):
            if layer_idx not in activations or layer_idx not in gradients:
                raise RuntimeError(f"Missing activation or gradient for selected layer {layer_idx}.")
            act = activations[layer_idx]
            grad = gradients[layer_idx]
            if act.shape != grad.shape:
                raise RuntimeError(f"Activation/gradient shape mismatch at layer {layer_idx}.")
            if act.ndim == 3:
                # Token attribution: sum channel-wise activation-gradient products.
                token_attr = F.relu((act * grad).sum(dim=-1))
                layer_map = _spatialize(token_attr.unsqueeze(-1), h, w)
            elif act.ndim == 4:
                layer_map = F.relu((act * grad).sum(dim=1, keepdim=True))
            else:
                raise ValueError(f"Unsupported activation rank {act.ndim} at layer {layer_idx}.")
            layer_map = F.interpolate(layer_map, size=(h, w), mode="bilinear", align_corners=False)
            weighted = self.layer_weights[pos].to(layer_map.device) * layer_map
            grad_map = weighted if grad_map is None else grad_map + weighted

        grad_map = normalize_map(grad_map)
        attn_map = self._attention_map(image, text, (h, w))
        if attn_map is None:
            # Do not silently claim a hybrid explanation when attention is unavailable.
            fused = grad_map
        else:
            attn_map = normalize_map(attn_map.to(grad_map.device))
            fused = self.fusion_weight * grad_map + (1.0 - self.fusion_weight) * attn_map
        fused = normalize_map(fused)
        return Explanation(
            attribution=fused.detach(),
            gradient_attribution=grad_map.detach(),
            attention_attribution=None if attn_map is None else attn_map.detach(),
            selected_layers=list(self.selected_layers),
            layer_weights=self.layer_weights.detach().clone(),
        )

    def _attention_map(self, image, text, size):
        maps = list(self.adapter.attention_maps(image, text))
        if not maps:
            return None
        patch_scores = []
        for attention in maps:
            # Expected [B, heads, text_or_query_tokens, image_patch_tokens].
            if attention.ndim != 4:
                raise ValueError("Attention tensors must have shape [B, heads, query, key].")
            patch_scores.append(attention.float().mean(dim=(1, 2)))
        scores = torch.stack(patch_scores, dim=0).mean(dim=0)
        n = scores.shape[-1]
        side = math.isqrt(n)
        if side * side != n and n > 1 and math.isqrt(n - 1) ** 2 == n - 1:
            scores = scores[..., 1:]
            n -= 1
            side = math.isqrt(n)
        if side * side != n:
            raise ValueError("Attention key dimension is not a square patch grid.")
        result = scores.reshape(scores.shape[0], 1, side, side)
        return F.interpolate(result, size=size, mode="bilinear", align_corners=False)
