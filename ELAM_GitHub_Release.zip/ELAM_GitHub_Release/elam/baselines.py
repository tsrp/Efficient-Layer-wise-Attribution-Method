"""Gradient and attention attribution baselines built on the same adapter contract."""
from __future__ import annotations
from typing import Optional
import torch
import torch.nn.functional as F
from torch import Tensor
from .core import VLMAdapter, normalize_map


def gradient_x_input(adapter: VLMAdapter, image: Tensor, text: str) -> Tensor:
    x = image.detach().clone().requires_grad_(True)
    adapter.model_zero_grad() if hasattr(adapter, "model_zero_grad") else None
    score = adapter.score(x, text)
    score.reshape(-1).mean().backward()
    attr = (x * x.grad).sum(dim=1, keepdim=True).relu()
    return normalize_map(F.interpolate(attr, size=image.shape[-2:], mode="bilinear", align_corners=False))


def integrated_gradients(
    adapter: VLMAdapter, image: Tensor, text: str, steps: int = 50,
    baseline: Optional[Tensor] = None
) -> Tensor:
    baseline = torch.zeros_like(image) if baseline is None else baseline.to(image.device)
    total_grad = torch.zeros_like(image)
    # Trapezoidal integration includes both endpoints.
    for alpha in torch.linspace(0, 1, steps + 1, device=image.device):
        x = (baseline + alpha * (image - baseline)).detach().requires_grad_(True)
        adapter.model_zero_grad() if hasattr(adapter, "model_zero_grad") else None
        score = adapter.score(x, text)
        score.reshape(-1).mean().backward()
        weight = 0.5 if alpha.item() in (0.0, 1.0) else 1.0
        total_grad += weight * x.grad.detach()
    total_grad /= max(steps, 1)
    attr = ((image - baseline) * total_grad).sum(dim=1, keepdim=True).relu()
    return normalize_map(F.interpolate(attr, size=image.shape[-2:], mode="bilinear", align_corners=False))


def attention_rollout(attention_layers, image_size):
    """Attention rollout for square self-attention maps [B,heads,tokens,tokens]."""
    if not attention_layers:
        raise ValueError("No attention matrices were provided.")
    joint = None
    for attn in attention_layers:
        if attn.ndim != 4 or attn.shape[-1] != attn.shape[-2]:
            raise ValueError("Each attention matrix must be [B,heads,N,N].")
        a = attn.float().mean(dim=1)
        eye = torch.eye(a.shape[-1], device=a.device).unsqueeze(0)
        a = a + eye
        a = a / a.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        joint = a if joint is None else torch.bmm(a, joint)
    # CLS-to-patch relevance when a CLS token exists.
    relevance = joint[:, 0, 1:]
    n = relevance.shape[-1]
    side = int(n ** 0.5)
    if side * side != n:
        raise ValueError("After CLS removal, token count must form a square grid.")
    heat = relevance.reshape(-1, 1, side, side)
    heat = F.interpolate(heat, size=image_size, mode="bilinear", align_corners=False)
    return normalize_map(heat)


def transformer_attribution(adapter: VLMAdapter, image: Tensor, text: str, image_size):
    """Gradient-weighted attention aggregation.

    Adapter must expose attention tensors whose gradients are retained by its
    attention_maps_with_grad method. This explicit requirement avoids silently
    substituting ordinary attention rollout for Transformer Attribution.
    """
    if not hasattr(adapter, "attention_maps_with_grad"):
        raise NotImplementedError(
            "Implement adapter.attention_maps_with_grad(image, text) to return "
            "attention tensors with gradients; plain attention weights are not TA."
        )
    maps = adapter.attention_maps_with_grad(image, text)
    weighted = []
    for attn, grad in maps:
        if attn.shape != grad.shape:
            raise ValueError("Attention and attention-gradient shapes differ.")
        weighted.append((attn * grad).relu().mean(dim=(1, 2)))
    if not weighted:
        raise RuntimeError("No gradient-weighted attention maps were captured.")
    patch = torch.stack(weighted).mean(dim=0)
    n = patch.shape[-1]
    side = int(n ** 0.5)
    if side * side != n:
        raise ValueError("Patch-token count must form a square grid.")
    return normalize_map(F.interpolate(
        patch.reshape(-1, 1, side, side), size=image_size,
        mode="bilinear", align_corners=False
    ))
