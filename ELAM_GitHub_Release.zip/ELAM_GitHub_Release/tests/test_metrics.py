import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch
from elam.metrics import insertion_deletion, pointing_game, fidelity_retention


def test_pointing_game_hit_and_miss():
    heat = torch.zeros(1, 1, 8, 8)
    heat[0, 0, 2, 3] = 1.0
    assert pointing_game(heat, [(2, 1, 4, 3)]) == 1
    assert pointing_game(heat, [(5, 5, 7, 7)]) == 0


def test_insdel_is_deterministic():
    image = torch.ones(1, 1, 4, 4)
    attr = torch.arange(16, dtype=torch.float32).reshape(1, 1, 4, 4)
    def score_fn(x):
        return x.mean()
    a = insertion_deletion(image, attr, score_fn, steps=4)
    b = insertion_deletion(image, attr, score_fn, steps=4)
    assert a["insdel"] == b["insdel"]
    assert len(a["insertion_curve"]) == 5


def test_retention():
    assert fidelity_retention(0.5, 1.0) == 50.0
