# Efficient Layer-wise Attribution Method (ELAM)

This repository is a cleaned, modular replacement for the original notebook. It removes
random-number placeholders and empty hook implementations and separates the method's
model-independent logic from architecture-specific VLM integration.

## Important reproducibility note

The manuscript describes experiments on CLIP-ViT-L/14, BLIP-2 and LLaVA-1.5-7B,
with MS-COCO and Flickr30k, and reports five baselines plus insertion-deletion and
pointing-game evaluation. The uploaded notebook did **not** contain working
implementations of those experiments. This release therefore provides the reusable
ELAM core, real gradient-based attribution routines, insertion/deletion and pointing
game metrics, timing/memory measurement, and explicit adapter interfaces.

It does not claim that Tables 2–5 or Figures 2–4 have been reproduced. Before making
that claim in a paper or response letter, implement and test adapters for the exact
Transformers versions/checkpoints, run the full 2,500-pair protocol, save per-sample
outputs, and compare the regenerated results with the manuscript. In particular,
cross-modal attention extraction is architecture-dependent: CLIP is a dual encoder
and does not have a native cross-modal attention block; BLIP-2 and LLaVA expose
different multimodal pathways. Do not report hybrid attention results for an adapter
that returns no attention maps.

## Repository layout

```text
ELAM_GitHub_Release/
├── elam/
│   ├── __init__.py
│   ├── core.py
│   ├── metrics.py
│   └── baselines.py
├── tests/
│   └── test_metrics.py
├── requirements.txt
└── README.md
```

## Installation

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1

pip install -r requirements.txt
```

Install a PyTorch build matching your CUDA version from https://pytorch.org/get-started/locally/.

## Adapter contract

Implement a class derived from `elam.VLMAdapter`:

- `score(image, text)`: return a **single scalar tensor** (for example, the image-text
  similarity logit or the log-likelihood of a specified target answer).
- `visual_layers()`: return ordered visual/multimodal modules whose outputs retain
  patch tokens or spatial feature maps.
- `attention_maps(image, text)`: optionally return selected attention tensors with
  shape `[batch, heads, query_tokens, image_patch_tokens]`.
- `model_zero_grad()`: recommended; clear model gradients before each backward pass.

The adapter must use the same image preprocessing and scalar target definition for
ELAM and every baseline. For generative VLMs, define the target text/token sequence
explicitly; otherwise scores across methods will not be comparable.

## Minimal usage

```python
import torch
from elam import ELAM

# `adapter` is your tested architecture-specific VLMAdapter implementation.
# `calibration_samples` is a list of (preprocessed_image_tensor, text) pairs.
method = ELAM(adapter, num_layers=5, fusion_weight=0.73)
method.calibrate(calibration_samples)
explanation = method.explain(image_tensor, caption)

heatmap = explanation.attribution
print(explanation.selected_layers)
```

The image tensor is expected to be `[1, C, H, W]`. For token-based layers, the
number of patch tokens must form a square grid after optional CLS-token removal.
If your architecture uses non-square patches, multiple image crops, or non-spatial
multimodal tokens, override the spatial conversion in the adapter/model integration.

## Evaluation

`elam.metrics.insertion_deletion` computes insertion AUC, deletion AUC and
`InsDel = insertion_AUC - deletion_AUC`. Its `score_fn` must return the same scalar
target used to create the attribution. The default baseline is a zero-valued tensor;
for normalized images, consider using a documented blur/mean baseline consistently.

`pointing_game` expects boxes in `(x1, y1, x2, y2)` coordinates in the attribution
map's pixel coordinate system. It returns `None` if no boxes are provided. Flickr30k
does not automatically provide object boxes; obtain and document a compatible
annotation source before reporting pointing-game accuracy for that dataset.

The baseline module includes Integrated Gradients (50 steps can be selected),
Gradient × Input, Attention Rollout, and an explicit Transformer Attribution
interface. GradCAM is architecture-specific; it should be added only for a suitable
convolutional target layer or a documented ViT adaptation. The Transformer
Attribution function intentionally raises `NotImplementedError` until the adapter
provides attention tensors and their gradients.

## Dataset protocol matching the manuscript

- Calibration: 50 samples from MS-COCO training split, disjoint from evaluation.
- Evaluation: 1,500 MS-COCO validation samples and 1,000 Flickr30k test samples.
- Models: CLIP-ViT-L/14, BLIP-2 (OPT-2.7B), LLaVA-1.5-7B.
- Baselines: Integrated Gradients (50 steps), Gradient × Input, GradCAM,
  Attention Rollout, Transformer Attribution.
- Record per-sample runtime, peak allocated GPU memory, InsDel, and pointing-game
  hit/miss where valid bounding boxes are available.

Do not replace failed image downloads with gray images: log and exclude failures so
that the reported sample count remains accurate. Save model/checkpoint IDs,
library versions, random seeds, precision, GPU count, offloading configuration,
and all metric definitions with each run.

## Citation and license

Add the manuscript citation and a license appropriate to the authors' intended
distribution before making the repository public.
